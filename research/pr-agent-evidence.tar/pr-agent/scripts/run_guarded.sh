#!/usr/bin/env bash
# Usage: run_guarded.sh <label> <pr-agent cli args...>
# Runs PR-Agent 0.49.0 under guard.py with a clean environment. Writes logs to out/<label>/.
set -euo pipefail
SP=/tmp/claude-1000/-home-snregales-Projects-kalonji-tools/9e81673b-052a-450d-8372-0b568fe1240c/scratchpad/pr-agent
label=$1; shift
dir=$SP/out/$label
mkdir -p "$dir" "$SP/run/home"
rm -f "$dir/net.jsonl" "$dir/sink.jsonl"
token=$(gh auth token --user snregales-agent)
cd "$SP/run"
env -i PATH=/usr/bin:/bin HOME="$SP/run/home" LITELLM_LOCAL_MODEL_COST_MAP=True LOG_LEVEL=DEBUG \
  GH_READ_TOKEN="$token" STUB_BASE="http://127.0.0.1:18765/v1" SINK_FILE="$dir/sink.jsonl" \
  ${NO_KEY_MODEL:+NO_KEY_MODEL="$NO_KEY_MODEL"} \
  "$SP/venv/bin/python" -I "$SP/scripts/guard.py" run "$dir/net.jsonl" -- "$@" \
  > "$dir/stdout.txt" 2> "$dir/stderr.txt" && rc=0 || rc=$?
echo "rc=$rc"
echo "--- net verdicts:"; jq -r '[.layer,.verdict,(.method//"-"),(.host//"-"),(.url//"")]|@tsv' "$dir/net.jsonl" | sort | uniq -c | sort -rn | head -40

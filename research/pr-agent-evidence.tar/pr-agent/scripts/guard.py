"""Run the PR-Agent CLI under a network guard that makes a write to GitHub impossible.

Usage:
  python -I guard.py selftest <net_log>
  python -I guard.py run <net_log> -- <pr-agent cli args...>

The guard does four things before PR-Agent starts:
  1. socket.getaddrinfo: only api.github.com, github.com and 127.0.0.1 resolve. Any other host
     is refused and logged, so nothing else leaves the machine.
  2. http.client, httpx and aiohttp: any method other than GET or HEAD to a GitHub host is
     refused and logged before a byte is sent.
  3. Host settings: model -> local stub, GitHub read token, repo settings file OFF.
  4. Each tool's run() asserts config.publish_output is False on entry, else the process exits.
"""
import json
import os
import socket
import sys
import time

MODE = sys.argv[1]
NET_LOG = sys.argv[2]
ALLOWED_HOSTS = {"api.github.com", "github.com", "127.0.0.1", "localhost", "openaipublic.blob.core.windows.net"}  # last: tiktoken encoding download
READ_METHODS = {"GET", "HEAD"}


def log(event: dict) -> None:
    event["t"] = round(time.time(), 3)
    with open(NET_LOG, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(event) + "\n")


def is_github(host: str) -> bool:
    host = (host or "").lower().split(":")[0]
    return host == "github.com" or host.endswith(".github.com")


# 1. Host allowlist at name resolution.
_real_getaddrinfo = socket.getaddrinfo


def guarded_getaddrinfo(host, *args, **kwargs):
    name = host.decode() if isinstance(host, bytes) else str(host)
    if name not in ALLOWED_HOSTS:
        log({"layer": "dns", "host": name, "verdict": "BLOCKED-HOST"})
        raise socket.gaierror(f"guard: host {name} is not allowed")
    log({"layer": "dns", "host": name, "verdict": "allowed"})
    return _real_getaddrinfo(host, *args, **kwargs)


socket.getaddrinfo = guarded_getaddrinfo


class BlockedWrite(RuntimeError):
    pass


import threading  # noqa: E402

_graphql_read = threading.local()


def check(layer: str, method: str, host: str, url: str) -> None:
    method = (method or "").upper()
    if is_github(host) and method not in READ_METHODS:
        if (layer == "http.client" and method == "POST" and url.split("?")[0].endswith("/graphql")
                and getattr(_graphql_read, "ok", False)):
            log({"layer": layer, "method": method, "host": host, "url": url, "verdict": "allowed-graphql-query"})
            return
        log({"layer": layer, "method": method, "host": host, "url": url, "verdict": "BLOCKED-WRITE"})
        raise BlockedWrite(f"guard: refused {method} {url}")
    log({"layer": layer, "method": method, "host": host, "url": url, "verdict": "allowed"})


# 2a. http.client (requests, urllib3, PyGithub all end here).
import http.client  # noqa: E402

_real_putrequest = http.client.HTTPConnection.putrequest


def guarded_putrequest(self, method, url, *args, **kwargs):
    check("http.client", method, self.host, url)
    return _real_putrequest(self, method, url, *args, **kwargs)


http.client.HTTPConnection.putrequest = guarded_putrequest

# 2a'. A GraphQL POST is a read only when its body is a query. urllib3 sees the body, so it
# decides here; anything else (a mutation, an unparsable body) stays refused at http.client.
import urllib3.connectionpool  # noqa: E402

_real_urlopen = urllib3.connectionpool.HTTPConnectionPool.urlopen


def guarded_urlopen(self, method, url, body=None, *args, **kwargs):
    ok = False
    if is_github(self.host) and str(method).upper() == "POST" and str(url).split("?")[0].endswith("/graphql"):
        try:
            text = body.decode() if isinstance(body, bytes) else str(body)
            query = json.loads(text).get("query", "").lstrip()
            ok = query.startswith("{") or query.startswith("query")
        except Exception:  # noqa: BLE001
            ok = False
        log({"layer": "urllib3-graphql", "verdict": "query" if ok else "not-a-query",
             "head": (query[:60] if ok else "")})
    _graphql_read.ok = ok
    try:
        return _real_urlopen(self, method, url, body, *args, **kwargs)
    finally:
        _graphql_read.ok = False


urllib3.connectionpool.HTTPConnectionPool.urlopen = guarded_urlopen

# 2b. httpx (LiteLLM, OpenAI SDK).
import httpx  # noqa: E402

_real_send = httpx.Client.send
_real_asend = httpx.AsyncClient.send


def guarded_send(self, request, *args, **kwargs):
    check("httpx", request.method, request.url.host, str(request.url))
    return _real_send(self, request, *args, **kwargs)


async def guarded_asend(self, request, *args, **kwargs):
    check("httpx-async", request.method, request.url.host, str(request.url))
    return await _real_asend(self, request, *args, **kwargs)


httpx.Client.send = guarded_send
httpx.AsyncClient.send = guarded_asend

# 2c. aiohttp.
import aiohttp  # noqa: E402
from yarl import URL  # noqa: E402

_real_request = aiohttp.ClientSession._request


async def guarded_request(self, method, str_or_url, *args, **kwargs):
    url = URL(str(str_or_url))
    check("aiohttp", method, url.host or "", str(url))
    return await _real_request(self, method, str_or_url, *args, **kwargs)


aiohttp.ClientSession._request = guarded_request


def selftest() -> int:
    """Prove each layer refuses a write. POST /markdown only renders text; it writes nothing."""
    import asyncio

    import requests

    results = {}
    target = "https://api.github.com/markdown"
    try:
        requests.post(target, json={"text": "guard self-test"}, timeout=10)
        results["requests"] = "SENT (guard failed)"
    except BlockedWrite:
        results["requests"] = "blocked"
    try:
        httpx.post(target, json={"text": "guard self-test"}, timeout=10)
        results["httpx"] = "SENT (guard failed)"
    except BlockedWrite:
        results["httpx"] = "blocked"

    async def via_aiohttp():
        async with aiohttp.ClientSession() as session:
            async with session.post(target, json={"text": "guard self-test"}):
                return "SENT (guard failed)"

    try:
        results["aiohttp"] = asyncio.run(via_aiohttp())
    except BlockedWrite:
        results["aiohttp"] = "blocked"
    try:
        socket.getaddrinfo("example.com", 443)
        results["dns example.com"] = "resolved (guard failed)"
    except socket.gaierror:
        results["dns example.com"] = "blocked"
    token = os.environ.get("GH_READ_TOKEN", "")
    auth = {"Authorization": f"bearer {token}"} if token else {}
    try:
        # A no-op mutation (it only asks for the root type's name); it must never leave.
        requests.post("https://api.github.com/graphql", json={"query": "mutation { __typename }"},
                      headers=auth, timeout=10)
        results["graphql mutation"] = "SENT (guard failed)"
    except BlockedWrite:
        results["graphql mutation"] = "blocked"
    try:
        status = requests.post("https://api.github.com/graphql", json={"query": "{ rateLimit { remaining } }"},
                               headers=auth, timeout=10).status_code
        results["graphql query"] = f"allowed, HTTP {status}"
    except BlockedWrite:
        results["graphql query"] = "blocked"
    try:
        status = requests.get("https://api.github.com/zen", timeout=10).status_code
        results["GET api.github.com/zen"] = f"allowed, HTTP {status}"
    except Exception as error:  # noqa: BLE001
        results["GET api.github.com/zen"] = f"error {error}"
    for key, value in results.items():
        print(f"{key:28} {value}")
    return 0 if all("guard failed" not in v for v in results.values()) else 1


def run(cli_args: list[str]) -> int:
    from pr_agent.config_loader import get_settings

    settings = get_settings()
    settings.set("GITHUB.USER_TOKEN", os.environ["GH_READ_TOKEN"])
    settings.set("GITHUB.DEPLOYMENT_TYPE", "user")
    settings.set("CONFIG.USE_REPO_SETTINGS_FILE", False)
    settings.set("CONFIG.USE_GLOBAL_SETTINGS_FILE", False)
    settings.set("CONFIG.PUBLISH_OUTPUT", False)
    settings.set("CONFIG.PUBLISH_OUTPUT_PROGRESS", False)
    settings.set("CONFIG.FALLBACK_MODELS", [])
    if os.environ.get("NO_KEY_MODEL"):
        # No key at all: show where a real run stops.
        settings.set("CONFIG.MODEL", os.environ["NO_KEY_MODEL"])
    else:
        settings.set("CONFIG.MODEL", "openai/stub-model")
        settings.set("CONFIG.CUSTOM_MODEL_MAX_TOKENS", 1000000)
        settings.set("OPENAI.KEY", "stub-key-not-a-secret")
        settings.set("OPENAI.API_BASE", os.environ["STUB_BASE"])
    settings.set("PUSH_OUTPUTS.ENABLE", True)
    settings.set("PUSH_OUTPUTS.CHANNELS", ["stdout", "file"])
    settings.set("PUSH_OUTPUTS.FILE_PATH", os.environ["SINK_FILE"])

    from pr_agent.tools import (pr_code_suggestions, pr_description, pr_questions, pr_reviewer,
                                pr_update_changelog)

    def assert_no_publish(cls):
        real_run = cls.run

        async def run_checked(self, *args, **kwargs):
            value = get_settings().config.publish_output
            log({"layer": "tool-entry", "tool": cls.__name__, "publish_output": value})
            print(f"guard: {cls.__name__}.run entered with config.publish_output={value}", flush=True)
            plain_diff = get_settings().config.get("git_provider") == "plain-diff"
            if plain_diff:
                # Plain-diff mode forces publish_output on: its provider writes to stdout only.
                # The network guard above still refuses any GitHub write.
                print(f"guard: git_provider=plain-diff, so publish_output={value} goes to stdout", flush=True)
            elif value is not False:
                print("guard: publish_output is not False; aborting", flush=True)
                os._exit(3)
            return await real_run(self, *args, **kwargs)

        cls.run = run_checked

    for cls in (pr_reviewer.PRReviewer, pr_code_suggestions.PRCodeSuggestions, pr_description.PRDescription,
                pr_questions.PRQuestions, pr_update_changelog.PRUpdateChangelog):
        assert_no_publish(cls)

    from pr_agent import cli

    return cli.run(inargs=cli_args) or 0


if MODE == "selftest":
    sys.exit(selftest())
elif MODE == "run":
    sep = sys.argv.index("--")
    sys.exit(run(sys.argv[sep + 1:]))
else:
    sys.exit(f"unknown mode {MODE}")

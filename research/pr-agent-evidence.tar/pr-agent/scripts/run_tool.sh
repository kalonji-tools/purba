#!/usr/bin/env bash
# Usage: run_tool.sh <label> <pr-agent cli args...>  — one guarded run against the stub;
# moves the stub's request logs into out/<label>/requests/.
set -uo pipefail
SP=/tmp/claude-1000/-home-snregales-Projects-kalonji-tools/9e81673b-052a-450d-8372-0b568fe1240c/scratchpad/pr-agent
label=$1; shift
mkdir -p "$SP/out/stub-requests"
find "$SP/out/stub-requests" -name '*.json' -newer "$SP/out/stub.log" -delete 2>/dev/null || true
"$SP/scripts/run_guarded.sh" "$label" "$@" | grep -v 'contents/'
mkdir -p "$SP/out/$label/requests"
find "$SP/out/stub-requests" -name '*.json' -exec mv {} "$SP/out/$label/requests/" \;
echo "model requests: $(find "$SP/out/$label/requests" -name '*.json' | wc -l)"
echo "--- tool log:"
sed 's/\x1b\[[0-9;]*m//g' "$SP/out/$label/stdout.txt" | grep -E '^20[0-9]{2}-.*(INFO|WARNING|ERROR)|^guard' | cut -c1-240 | grep -v 'Sub-issues fetched' | head -30

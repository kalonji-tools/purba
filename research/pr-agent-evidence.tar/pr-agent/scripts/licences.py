"""Print name, version and licence of every installed distribution, then a tally."""
import collections
import importlib.metadata as md

rows = []
for dist in md.distributions():
    meta = dist.metadata
    name = meta["Name"]
    expr = meta.get("License-Expression")
    lic = meta.get("License")
    classifiers = [c.split(" :: ")[-1] for c in (meta.get_all("Classifier") or []) if c.startswith("License ::")]
    if expr:
        value = expr
    elif classifiers:
        value = "; ".join(classifiers)
    elif lic and len(lic) < 60:
        value = lic.strip()
    elif lic:
        value = "LICENSE-TEXT:" + lic.strip().splitlines()[0][:50]
    else:
        value = "UNKNOWN"
    rows.append((name.lower(), dist.version, value))

rows.sort()
for row in rows:
    print("\t".join(row))
print("----")
tally = collections.Counter(row[2] for row in rows)
for value, count in tally.most_common():
    print(f"{count}\t{value}")
print(f"total\t{len(rows)}")

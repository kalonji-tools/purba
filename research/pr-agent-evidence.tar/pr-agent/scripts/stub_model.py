"""A local OpenAI-compatible stub. It logs each request body and returns canned YAML.

Usage: python -I stub_model.py <port> <log_dir>
It never forwards anything. It exists so a PR-Agent run gets past the model call.
"""
import json
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PORT = int(sys.argv[1])
LOG_DIR = Path(sys.argv[2])
LOG_DIR.mkdir(parents=True, exist_ok=True)
COUNTER = {"n": 0}

REVIEW = """```yaml
review:
  estimated_effort_to_review_[1-5]: 3
  relevant_tests: |
    No
  key_issues_to_review:
    - relevant_file: |
        tests/bats/errors.bats
      issue_header: |
        Stub finding
      issue_content: |
        STUB: this finding comes from a local stub, not a model.
      start_line: 1
      end_line: 2
  security_concerns: |
    Yes, STUB security concern to exercise the label path.
```"""

IMPROVE = """```yaml
code_suggestions:
  - relevant_file: |
      tests/bats/errors.bats
    language: |
      bash
    existing_code: |
      x
    suggestion_content: |
      STUB suggestion from a local stub.
    improved_code: |
      y
    one_sentence_summary: |
      STUB suggestion
    label: |
      possible issue
```"""

REFLECT = """```yaml
code_suggestions:
  - suggestion_summary: |
      STUB suggestion
    relevant_file: |
      tests/bats/errors.bats
    relevant_lines_start: 1
    relevant_lines_end: 2
    suggestion_score: 8
    why: |
      STUB
```"""

DESCRIBE = """```yaml
type:
  - Tests
description: |
  STUB description from a local stub.
title: |
  STUB title
pr_files: []
```"""


def pick(body: dict) -> str:
    messages = body.get("messages") or [{}]
    system = str(messages[0].get("content", ""))
    if "evaluating code suggestions" in system or "evaluate the correctness and importance" in system:
        return REFLECT
    if "code analysis and suggestions" in system:
        return IMPROVE
    if "Your task is to provide constructive and concise feedback" in system:
        return REVIEW
    if "PR-Changelog-Updater" in system:
        return "```\n- STUB changelog line from a local stub.\n```"
    if "answer questions about a Git Pull Request" in system:
        return "STUB answer from a local stub."
    return DESCRIBE


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("content-length", 0))
        raw = self.rfile.read(length)
        COUNTER["n"] += 1
        n = COUNTER["n"]
        try:
            body = json.loads(raw)
        except json.JSONDecodeError:
            body = {"_raw": raw.decode("utf-8", "replace")}
        safe_headers = {k: ("<redacted>" if k.lower() in ("authorization", "api-key", "x-api-key") else v)
                        for k, v in self.headers.items()}
        (LOG_DIR / f"{n:03d}.json").write_text(json.dumps(
            {"path": self.path, "headers": safe_headers, "body": body}, indent=1))
        content = pick(body)
        model = body.get("model", "stub")
        if body.get("stream"):
            self.send_response(200)
            self.send_header("content-type", "text/event-stream")
            self.end_headers()
            chunk = {"id": f"stub-{n}", "object": "chat.completion.chunk", "created": int(time.time()),
                     "model": model, "choices": [{"index": 0, "delta": {"role": "assistant", "content": content},
                                                  "finish_reason": None}]}
            self.wfile.write(f"data: {json.dumps(chunk)}\n\n".encode())
            end = dict(chunk, choices=[{"index": 0, "delta": {}, "finish_reason": "stop"}])
            self.wfile.write(f"data: {json.dumps(end)}\n\n".encode())
            self.wfile.write(b"data: [DONE]\n\n")
            return
        reply = {"id": f"stub-{n}", "object": "chat.completion", "created": int(time.time()), "model": model,
                 "choices": [{"index": 0, "message": {"role": "assistant", "content": content},
                              "finish_reason": "stop"}],
                 "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2}}
        data = json.dumps(reply).encode()
        self.send_response(200)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        sys.stderr.write("stub: " + (fmt % args) + "\n")


ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()

"""Measure each logged model request: characters, an o200k token estimate, and which inputs it carries.

Usage: python -I measure.py <out_dir> <label>...
The token figure is tiktoken's o200k_base count. It is an ESTIMATE for a Claude model:
Claude's tokenizer is different, and no Anthropic token count was possible without a key.
"""
import json
import sys
from pathlib import Path

import tiktoken

enc = tiktoken.get_encoding("o200k_base")
out = Path(sys.argv[1])
MARKERS = {
    "AGENTS.md": ["AGENTS.md"],
    "ticket (issue body)": ["--PR Ticket Info--", "Ticket Description:"],
    "PR body": ["## Implementation plan"],
    "PR title": ["Title: 'feat: exit 125"],
    "branch": ["Branch: 'feat/728"],
    "commit messages": ["Commit messages", "commit_messages"],
    "diff": ["## File: '"],
    "CHANGELOG.md": ["CHANGELOG.md"],
    "question": ["restore the default hook"],
}
print("label\treq\tsystem_chars\tuser_chars\tsystem_tok\tuser_tok\ttotal_tok\tcarries")
for label in sys.argv[2:]:
    grand = 0
    for path in sorted((out / label / "requests").glob("*.json")):
        body = json.loads(path.read_text())["body"]
        msgs = body.get("messages", [])
        system = "".join(str(m.get("content", "")) for m in msgs if m.get("role") == "system")
        user = "".join(str(m.get("content", "")) for m in msgs if m.get("role") != "system")
        both = system + user
        st, ut = len(enc.encode(system, disallowed_special=())), len(enc.encode(user, disallowed_special=()))
        grand += st + ut
        carries = [name for name, keys in MARKERS.items() if any(k in both for k in keys)]
        print(f"{label}\t{path.stem}\t{len(system)}\t{len(user)}\t{st}\t{ut}\t{st + ut}\t{', '.join(carries)}")
    print(f"{label}\tALL\t\t\t\t\t{grand}")

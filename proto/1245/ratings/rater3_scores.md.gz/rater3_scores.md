# Rater 3's report

Word for word, as the rater returned it. In this rater's folder `PORT_R` = purba A, `PORT_S` = oxitest, `PORT_T` = purba B ([`KEY.txt`](KEY.txt)).

Rater 3 report. All scratch work is in `<eval>/blind/rater3/_review/` (c3 = edits, c6 = minimum tests, c7 = fidelity probes, c8 = root copies, c9 = test-files copies, c10 = seeded failures).

Summary: All four versions run 20 items and all pass. PORT_R and PORT_T have the same test file byte for byte (`cmp` says identical) and the same TESTS.md. They differ only in how the runner words its root line and its test-files errors. T's wording names the cause and the fix, so T wins criteria 8 and 9. PORT_S (oxitest) reads clearly and its failures say most about intent, and it is the only version that type-checks clean. But its root and test-file handling is the weakest of the four: `python_files = []` runs nothing and still exits 0. The original pytest file is still the easiest to change. In R and T, one probe showed a real loss: when the expected exception is not raised, the case is "blocked" with a project error (exit 4) instead of "failed".

1. SCORES (5 = best; for the complexity rows, 5 = simplest)

| criterion | ORIGINAL | R | S | T |
|---|---|---|---|---|
| 1 Readability | 4 | 4 | 3 | 4 |
| 2 Clarity | 4 | 3 | 5 | 3 |
| 3 Ease of use | 5 | 3 | 4 | 3 |
| 4 Tester complexity | 3 | 3 | 2 | 3 |
| 5 Impl. complexity | 2 | 3 | 2 | 3 |
| 6 Minimum test | 5 | 4 | 4 | 4 |
| 7 Fidelity | ref (5) | 4 | 5 | 4 |
| 8 Run start | 3 | 4 | 2 | 5 |
| 9 Test files | 2 | 4 | 1 | 5 |
| 10 Seeded failures | 5 | 4 | 4 | 4 |

2. PER VERSION

ORIGINAL (pytest), 67 non-blank lines + 22 in conftest
- Strongest: the change cost. The new case was 1 line (`("g", "{message}!", "g!\n")`) and the new test was 4 lines. Both passed first time (22 passed).
- Strongest: the failure output gives file:line, the source and a caret diff (`tests/test_add_option_format.py:56`).
- Weakest: `writer` is injected through conftest by its parameter name, and it is untyped. ty and pyright see nothing in the new test, and the 9 errors they report are all in conftest. The ids are not informative: `test_format[e-<lambda>-e]`, `test_invalid_format[format2]`.

PORT_R (purba, terse messages), 153 lines
- Strongest: the file is flat. There are no fixtures and no parametrize, and each test reads top to bottom. Habits from pytest are refused with tagged messages, for example `[computed-expected] line 13 computes expected, and an expected value is a literal`.
- Weakest: a regression in which nothing is raised is not shown as a failure. It prints `project error: [second-path] line 133 reaches line 39 of raised, which did not run…` and `1 blocked`, exit 4.
- Weakest: a new case costs a new 6-line function. pyright adds one error per `writer.read()` (26 errors before my edits, 28 after).

PORT_S (oxitest), 142 lines + 26 in __fixtures__.py
- Strongest: the intent is spelled out. There are named cases (`message_field`), a message on each assert, and the failure prints that message (`└ format 'Message: {message}' should render 'a' as 'Message: A\n'`). ty and pyright are both clean, and a typo in a case field (`expectd=`) is caught by ty, by pyright and at collection.
- Weakest: the ceremony. There are 4 dataclasses, a `TYPE_CHECKING` stand-in for `FormatFunction` (lines 15-23), and the ignore comments at line 137. My new test was refused (`bare-assert line 194`, exit 3), and the output did not say how to fix it.

PORT_T (purba, explained messages)
- Same test file as R, so it has the same strengths and weaknesses.
- The only difference is the output. The root line and the test-files errors give the cause and the fix: `holds test*.py, which is none of test_*.py, *_test.py, tests.py and test.py; the nearest is test_*.py`.

3. CRITERIA 8 AND 9, ONE LINE PER VERSION

Criterion 8 (where a run starts):
- ORIGINAL 3: from `tests/` the output prints `rootdir: …/ORIGINAL_pytest`, but the ids start at `test_add_option_format.py::` (cwd-relative). With only `.git`, from `tests/` the rootdir is `tests/` (.git is ignored). No reason is printed.
- R 4: `⚠ root …/PORT_R-git, from .git; PURBA_IMPLICIT_ROOT=1; no [tool.purba] found` names the step, and the ids match the root in all 6 runs. The reason is terse.
- S 2: it prints only `rootdir:`, which moves to `tests/` when there is no pyproject. On a pass it prints no ids (even with `-vv`). The failure ids are always absolute paths, so the root is invisible.
- T 5: `⚠ root …/PORT_T-none/tests is the working folder, because PURBA_IMPLICIT_ROOT is set and no pyproject.toml holds [tool.purba]; the id of each test starts here, and moves with the working folder`.

Criterion 9 (choosing the test files):
- ORIGINAL 2: with `python_files = ["test*.py"]` it silently collected only my decoy `test_decoy.py`, exit 0. With `[]` it printed "no tests ran", exit 5, with no hint. The string form was accepted and worked.
- R 4: all three wrong values give a project error, exit 4. But `test*.py` suggests `nearest: test_*.py`, which is the default and not the intended `*_test.py`. I needed TEST-FILES.md to fix it.
- S 1: the key `python_files` is not in `--help`. I found it only through an unknown-field error. `["test*.py"]` silently ran the decoy only (exit 0), and `[]` printed "no tests ran" and exited 0. The string form gave a clear error.
- T 5: every error was fixable from the output alone. The string error printed `write a list, such as ["*_test.py"]`, and the empty-list error listed all four patterns.

4. OVERALL RANKING

Weights (out of 100): Clarity 15, Ease 15, Fidelity 15, Readability 10, Tester complexity 10, Run start 10, Test files 10, Implementation complexity 5, Minimum test 5, Seeded failures 5. The original's fidelity counts as 5.
- ORIGINAL 3.90
- T 3.75
- R 3.55
- S 3.40

Ports only: T > R > S. R and T differ only in their messages, and T's messages are better. S has the best per-test clarity and type safety, but the worst run-start and test-file behaviour.

5. MINIMUM WORKING TEST (in _review/c6/<version>/tests/test_min.py, all pass)

| version | non-blank lines | imports | names the tester must know |
|---|---|---|---|
| ORIGINAL | 5 | 1 (`from loguru import logger`) | `test_` prefix, the `writer` fixture by parameter name, `.read()` |
| R | 6 | 1 | `test_` prefix, a literal expected value (`assert out == ["a\n"]`), `PURBA_IMPLICIT_ROOT=1` or `[tool.purba]` |
| T | 6 | 1 | same as R |
| S | 6 | 1 | `test_` prefix, a mandatory assert message under `strict = "abort"`; annotations are optional; the autouse reset applies implicitly |

6. BUGS AND ROUGH EDGES (not scored)

purba (R and T):
- It does not capture stderr. loguru's default-handler line `… | DEBUG | test_min:test_min:7 - a` leaked into the run output.
- A missing exception becomes a "blocked" project error, not a failure (see above).
- A failed case prints no file:line.
- R's `nearest: test_*.py` points to the default pattern.
- The NOTES.md for R and T are identical and partly out of date. They call `[foreign-framework]` and `[computed-expected]` "missing", but TESTS.md documents both. They say ROOT.md has no subfolder example, but it has one. They cite `../scratch/out/`, which is not in the folder.

oxitest (S):
- `-vv` (the command in RUN.md) still prints only dots.
- Failure headers are not consistent: `message_field - test_format` for one, `FAILED /abs/path::test_…` for the other.
- A test parameter with no fixture passes `strict = "abort"`. Its error then points into `oxitest/_bridge/_runners.py:201`.
- An exception in fixture teardown is only a notice, and the run exits 0. I confirmed the NOTES claim with an injected `RuntimeError`.
- By default it already collects `*_test.py`. The renamed file ran with no setting.

pytest (ORIGINAL):
- Started from `tests/`, the printed rootdir (the project) and the id prefix (cwd) disagree.

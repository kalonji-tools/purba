# Rater 1 (PORT_R = oxitest, PORT_T = purba)

The rater's final report, word for word, with its opening label dropped, the absolute path of its `_review/` folder left out, and its section titles set as headings.

All three versions run green as shipped: the pytest original gives 21 passed, the oxitest port (PORT_R) 21 passed, and the purba port (PORT_T) 24 passed, because PORT_T split the dateutil test into four. The ports trade strengths. The oxitest port is the clearest on screen and reruns failures best, but it is the heaviest to write in and handles a misspelled mark badly. The purba port is the easiest to learn and reports a misspelled name or tag best, but rerunning failures means copying a 120-character query, and when the code stops raising, it reports a project error instead of a failure. The original is the quickest to edit, but it says nothing when a test name is misspelled.

## 1. Scores (5 = best; on rows 4 and 5, 5 = simplest)

| Criterion | pytest original | oxitest port (PORT_R) | purba port (PORT_T) |
|---|---|---|---|
| 1 Readability | 4 | 3 | 4 |
| 2 Clarity | 3 | 5 | 3 |
| 3 Ease of use | 5 | 3 | 3 |
| 4 Complexity for the tester | 3 | 2 | 4 |
| 5 Complexity of the implementation | 2 | 2 | 3 |
| 6 Minimum working test | 5 | 4 | 5 |
| 7 Fidelity | reference | 5 | 4 |
| 8 Tagging | 3 | 2 | 4 |
| 9 Misspelled name | 1 | 4 | 5 |
| 10 Rerun failures | 4 | 5 | 3 |

## 2. Each version

- **pytest original**
  - Strongest: it is the shortest (87+30 lines), and the parametrize table reads at a glance. Adding case g was one line, and a new test was 4 lines with no friction.
  - Weakest: `writer` and the autouse reset are invisible from the test file. The ids are opaque (`test_invalid_format[format2]`), and no assert has a message.
  - ty reports 9 diagnostics and pyright 11 errors, all from the conftest copied as-is.
- **oxitest port (PORT_R)**
  - Strongest: named cases plus an intent message on every assert. A failure prints the case parameters and the message: `format 'Nope' should render 'b' as 'Nope?\n'`. It is clean under ty, and pyright shows only the 2 `_ymd` errors the original also has. ty caught my misspelled case field: `unknown-argument: mesage`.
  - Weakest: what you must learn and type. Each case needs a frozen dataclass, `oxi.parametrize` with keyword names, and a message on every assert. My new test's bare assert aborted the whole run with only `bare-assert line 81` and no fix hint.
  - The port needed 3 workarounds: `test_add_option_format.py:15-23` (a stub-only type), `Iterator` in place of `Yields`, and per-checker ignore comments.
- **purba port (PORT_T)**
  - Strongest: no hidden machinery. Every name is defined in the file, and the API has 2 public names (pytest has 91, oxitest 52). The refusal messages explain the fix, for example `[assert-before-expectation] … check this state in a test of its own`.
  - Weakest: repetition. Five near-identical markup tests (`:151-178`), three replays of the YMD setup, and one function per case (`test_format_a…g`, names with no meaning).
  - When I made `logger.add` stop raising, purba blocked the test as `project error: [second-path] line 206 reaches line 53 of add_error` with exit 4. pytest would report a failure ("DID NOT RAISE").
  - `purba.tag` is invisible to both type checkers: ty and pyright each give 4 errors (`Module purba has no member tag`).

## 3. Criteria 8, 9 and 10 — the deciding evidence

- **8 Tagging**
  - pytest original, 3: `-m smok` gives "23 deselected / 0 selected" and exit 5, with no hint. A misspelled decorator does get a `PytestUnknownMarkWarning … is this a typo?`.
  - oxitest port, 2: `-E 'mark(smok)'` silently ran the same 2 tests with exit 0, because it matches substrings (`mark(moke)` does too). A query that picks nothing exits 0 with "no tests ran". A misspelled decorator is refused with exit 3, but only on a full run.
  - purba port, 4: `tag(smok)` gives exit 3 and "the nearest tag is `smoke`". It cost 2 lines: the decorator and `import purba`. A misspelled decorator tag stays silent.
- **9 Misspelled name**
  - pytest original, 1: it collected 22 items instead of 23, with exit 0 and no message.
  - oxitest port, 4: `module-level-def tset_progressive_format line 84` aborts the run with exit 3. That catches it in CI, but the message is cryptic.
  - purba port, 5: `purba: name-near: tests/test_add_option_format.py:100: tset_progressive_format is not a test, and its name is near the prefix test`. The other tests still run, and the exit code is 0.
- **10 Rerun failures**
  - pytest original, 4: I typed `pytest -v --lf` three times. After I fixed case b, its id changed (the expected value is in the id), so `--lf` dropped it silently ("rerun previous 1 failure"). The fix was never confirmed.
  - oxitest port, 5: I typed `--lf` three times. After the fix the run printed "1 failed · 1 passed", which confirms the fix, because the case id `no_fields` stays the same.
  - purba port, 3: I had to copy and quote the 120-character query, then the 71-character one. The run confirmed the fix ("1 passed, 1 failed"). An unquoted paste failed in zsh, and nothing is kept between runs.

## 4. Ranking

Weighting: equal weight on the 9 criteria all three versions share (1–6, 8–10). Fidelity breaks ties between the ports only.

1. purba port: 34
2. pytest original: 30 (tied)
3. oxitest port: 30 (tied)

With fidelity added, the oxitest port reaches 35 against the purba port's 38. If clarity and ease of use counted double, the order would stay the same: purba port 40, pytest original 38, oxitest port 38.

**Fidelity detail (criterion 7)**

- **oxitest port:** it keeps every check. The `match=` regex and the "does not raise" mutants both fail. Looser: an exception in the teardown of `reset_logger` shows only as "21 warnings" with exit 0. I probed this and it confirms the port's own note.
- **purba port:** it keeps every input and expected value. The regex mutant fails 5 tests. The differences:
  - dateutil is split into 4 tests that replay the setup, which is equivalent.
  - It uses `is True` where the original asserts truthiness, which is slightly stricter.
  - The teardown reset is gone.
  - A "no longer raises" regression shows as a blocked test (exit 4), not a failure.

## 5. Minimum working test

`_review/min_{O,R,T}/tests/test_min.py`, all passing:

| | Non-blank lines | Imports | Names the tester must know |
|---|---|---|---|
| pytest original | 6 | 1 (`loguru.logger`) | the `test_` prefix, `assert` |
| oxitest port | 6 | 1 | the same, plus a required assert message |
| purba port | 6 | 1 | the `test_` prefix, the "one comparison with a literal" form |

In the oxitest port, the version's `strict = "abort"` aborted the bare assert with exit 3. Without strict it passes with a tip.

## 6. Bugs and rough edges (not scored)

- **purba port:**
  - A missing `import purba` is reported as `[foreign-decorator] the decorator purba.tag is not purba's`, which is misleading. `tag(smoke)` then silently skips that test with exit 0.
  - There is no output capture: loguru's stderr line printed in the minimum test run.
  - `purba --help` is read as a query.
- **oxitest port:**
  - The first failure header is `no_fields - test_format`, with no FAILED prefix and no path; the second failure has both.
  - `-vv` prints dots, not test names.
- **pytest original:** the `--lf` id drift described under criterion 10.
- **Unverified:** the purba port's NOTES items 1, 3, 4 and 5. I verified only `[second-path]`.
